import boto3
import time
import os

def lambda_handler(event, context):
    # Retrieve environment variables
    database = os.environ['ATHENA_DATABASE']
    table = os.environ['ATHENA_TABLE']
    s3_output = os.environ['S3_OUTPUT']
    cloudtrail_s3_bucket = os.environ['CLOUDTRAIL_S3_BUCKET']

    # Initialize the Athena client
    client = boto3.client('athena')

    # Define the SQL query
    query = f"""
    SELECT date_trunc('month', from_iso8601_timestamp(eventtime)) as month, count(*) as event_count
    FROM "{database}"."{table}"
    WHERE eventsource LIKE '%{cloudtrail_s3_bucket}%'
    GROUP BY 1
    """

    # Configuration for the query
    config = {
        'OutputLocation': f's3://{s3_output}/',
        'EncryptionConfiguration': {'EncryptionOption': 'SSE_S3'}
    }

    # Start the query execution
    execution = client.start_query_execution(
        QueryString=query,
        QueryExecutionContext={'Database': database},
        ResultConfiguration=config
    )
    
    # ... rest of the code remains the same ...
